﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Assesment1
{
    class Program
    {
        static void Main(string[] args)
        {
           /*SConsole.WriteLine("\n\nFirst program!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            Console.WriteLine("Sum of all elements of the array:");
            int[] arr = { 2, 5, 8 };
           
            Console.WriteLine(+arr[0] + arr[1] + arr[2]);



            Console.Write("\n\nSecond program!!!!!!!!!!!!!!!!!!!!!!!!!!!");

            int[] items = { 1,1,5,5,6};
            

            Console.WriteLine("Unique array elements: ");

            for (int i = 0; i < items.Length; i++)
            {
                bool isDuplicate = false;
                for (int j = 0; j < i; j++)
                {
                    if (items[i] == items[j])
                    {
                        isDuplicate = true;
                        break;
                    }
                }

                if (!isDuplicate)
                {
                    Console.WriteLine(items[i]);

                }
            }

            Console.ReadLine();
        



        Console.WriteLine("\n\nthird program!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

            int[,] matrix = new int[3,3];

            matrix[0,0] = 1;
            matrix[0,1] = 2;
            matrix[0,2] = 3;
            matrix[1,0] = 4;
            matrix[1,1] = 5;
            matrix[1,2] = 6;
            matrix[2,0] = 7;
            matrix[2,1] = 8;
            matrix[2,2] = 9;

 
            Console.Write("The matrix is : \n");
            for (int i = 0; i < 3; i++)
            {
                Console.Write("\n");
                for (int j = 0; j < 3; j++)
                    Console.Write( matrix[i, j]);
            }
            */


            Console.WriteLine("\n\n Fourth program!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");


            string username;
            string password;

            int count = 0; 
            do
            {
                Console.Write("Input a username: ");
                username = Console.ReadLine();

                Console.Write("Input a password: ");
                password = Console.ReadLine();

                if (username != "abcd" || password != "1234")
                    count++;
             

            }
            while ((username != "abcd" || password != "1234") && (count != 3));

            if (count == 3)
                Console.Write("\nLogin attemp three or more times. Try later!\n\n");
            else
                Console.Write("\nThe password entered successfully!\n\n");
        }
    }



    /*
                Console.WriteLine("\n\n fifth program!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                Console.WriteLine("enter a number");
                int num = Convert.ToInt32(Console.ReadLine());
                string romanResult = "";
                Dictionary<string, int> romanNumbersDictionary = new()
                {
                    {
                        "I",
                        1
                    },
                    {
                        "IV",
                        4
                    },
                    {
                        "V",
                        5
                    },
                    {
                        "IX",
                        9
                    },
                    {
                        "X",
                        10
                    },
                    {
                        "XL",
                        40
                    },
                    {
                        "L",
                        50
                    },
                    {
                        "XC",
                        90
                    },
                    {
                        "C",
                        100
                    },
                    {
                        "CD",
                        400
                    },
                    {
                        "D",
                        500
                    },
                    {
                        "CM",
                        900
                    },
                    {
                        "M",
                        1000
                    }
                };
                foreach (var item in romanNumbersDictionary.Reverse())
                {
                    if (num <= 0) break;
                    while (num >= item.Value)
                    {
                        romanResult += item.Key;
                        num -= item.Value;
                    }
                }
                Console.WriteLine(romanResult);*/
}
   // }


//    




/*Write a program in C# Sharp to find the sum of all elements of the array.  

Test Data : 

Input the number of elements to be stored in the array :3

Input 3 elements in the array : 

element - 0 : 2

element - 1 : 5

element - 2 : 8

Expected Output : 

Sum of all elements stored in the array is : 15


////////////////////////////

Write a program in C# SharpCo 

Test Data : 

Input the number of elements to be stored in the array :3

Input 3 elements in the array : 

element - 0 : 1

element - 1 : 5

element - 2 : 1

Expected Output : 

The unique elements found in the array are : 

5


///////////////////////////////////

Write a program in C# Sharp for a 2D array of size 3x3 and print the matrix.  

Test Data : 

Input elements in the matrix : 

element - [0],[0] : 1

element - [0],[1] : 2

element - [0],[2] : 3

element - [1],[0] : 4

element - [1],[1] : 5

element - [1],[2] : 6

element - [2],[0] : 7

element - [2],[1] : 8

element - [2],[2] : 9

Expected Output : 

The matrix is : 

 

1 2 3

4 5 6

7 8 9



////////////////////////


Write a program in C# Sharp to ch
Write a program in C# Sharp to check the username and password.  

Test Data : 

Input a username: uesr 

Input a password: pass 

Input a username: abcd 

Input a password: 1234 

Expected Output : 

Password entered successfully! 

 //////////////////////////

Write a C# Sharp program to compare four sets of words by using each member of the string comparison enumeration. The comparisons use the conventions of the English (United States) and Sami (Upper Sweden) cultures. 

Note : The strings "encyclopedia" and "encyclopedia" are considered equivalent in the en-US culture but not in the Sami (Northern Sweden) culture. 

Expected Output : 

   case = Case (CurrentCulture): False                                            
   case = Case (CurrentCultureIgnoreCase): True                                   
   case = Case (InvariantCulture): False                                          
   case = Case (InvariantCultureIgnoreCase): True                                 
   

 ////////////////////////////////////////////////////////

Write a program in C# Sharp to ch

Input the number of elements to store in the array [maximum 5 digits ] :3 

Input 3 number of elements in the array : 

element - 0 : 1 

element - 1 : 2 

element - 2 : 3 

Expected Output : 

The Permutations with a combination of 3 digits are : 

123 132 213 231 321 312
*/
